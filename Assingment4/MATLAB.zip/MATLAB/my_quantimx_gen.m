function output = my_quantimx_gen(N)
qmap = ones(N);
expo = 0:ceil(log2(N));
passsize = cumsum(2.^expo);
level = ones(size(qmap))*2;
for counter = expo
    if (N-passsize(counter+1)) < 0 
        break
    end
    mask = ~padarray(ones(passsize(counter+1)),[N,N] - [passsize(counter+1),passsize(counter+1)],'post');
    qmap = (mask .* level + ~mask).*qmap;
end
output = qmap;
figure('Name','Illustration of the quantization matrix');
subplot(1,2,1);imagesc(uint8(output));title('2D Plot');
subplot(1,2,2);mesh(uint8(output));title('Mesh Plot');
end