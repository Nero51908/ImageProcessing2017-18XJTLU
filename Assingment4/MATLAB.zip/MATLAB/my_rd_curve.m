function [psnr_vec,rate_vec,decoded_imo] = my_rd_curve(im,N,QP)
% parameter settins
% generation of quantization matrix according to N
Qmat = my_quantimx_gen(N);
% decoded images placeholder
decoded_imo = zeros(size(im,1),size(im,2),length(QP));
% place holder of output
rate_vec = zeros(length(QP),1);
psnr_vec = zeros(length(QP),1);
% evalueate rate
for QPf = QP
    % to perform image compression,  input: original im; Qmat; quantization parameter QP; Blocksize N; filename to be saved.
    rate_vec((QPf-1)/14+1) = my_compress_im(im,Qmat,QPf,N,['compressedLena_QP' num2str(QPf) 'N' num2str(N)]);
end
% evalueate PSNR
for counter = 1:length(QP)
    decoded_im = my_decompress_im(Qmat,QP(counter),N,['compressedLena_QP' num2str(QP(counter)) 'N' num2str(N)]);
    decoded_imo(:,:,counter) = decoded_im;
    psnr_vec(counter) = psnr(uint8(decoded_im), im);
end
end