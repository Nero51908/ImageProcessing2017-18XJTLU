function S = my_quality(QP)
%% Set quality factor 
if QP >= 100 || QP<=0
    disp('QP should be within (0,100)');
    return
end
% with valid QP input
if QP>50
    S = (100 - QP)/50;
else
    S = 50/QP;
end
end