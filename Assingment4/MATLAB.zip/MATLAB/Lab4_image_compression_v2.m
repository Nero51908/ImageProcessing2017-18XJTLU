%% Lab 4 Image Compression
%% Task 1 & Task 2 
%% Parameter settings
%%
demo_initialization;
%% Encoding Demo (Compression)
%%
demo_my_compress_im;
%% Decoding Demo (Decompression)
%%
disp(QP);
demo_my_decompress_im;
%% Task 3 (a) Parameter setting
%%
im = imread('lenna512.bmp');
N = 16;
QP = 1:14:99;
Qmat = my_quantimx_gen(N);
figure;
imshow(im);title('The original image is referred to as im in the following code.');
% % place holder
% rate = zeros(8,1);
% psnrval = zeros(8,1);
%% Task 3 (a) evalueate rate and PSNR
%%
% % Task 3 (a) evalueate rate
% for QPf = QP
%     rate((QPf-1)/14+1) = my_compress_im(im,Qmat,QPf,N,['compressedLena_QP' num2str(QPf)]);
% end
% % Task 3 (a) evalueate PSNR
% % placeholder
% decoded_im = zeros(size(im,1),size(im,2),8);
% for counter = 1:8
%     decoded_im(:,:,counter) = my_decompress_im(Qmat,QP(counter),N,['compressedLena_QP' num2str(QP(counter))],im);
%     psnrval(counter) = psnr(uint8(decoded_im(:,:,counter)));
% end
[psnrval_N_16,rate_N_16,decoded_im_N_16] = my_rd_curve(im,16,1:14:99);
%% Task 3 (a) Show Rate and PSNR
%%
disp('Rate vector is: ');disp(rate_N_16);
disp('PSNR vector is: ');disp(psnrval_N_16);
%% Task 3 (b) Plot PSNR vs Rate
%%
figure('Name','PSNR vs Rate for N = 16, QP = 1:14:99');
plot(rate_N_16, psnrval_N_16, '-bx');title('PSNR v.s. Compression Rate');
xlabel('Rate (bpp)');
ylabel('PSNR (dB)');
%% Task 3 (c) Comparing the engine used with JPEG
%%
% placeholder
jpeg_psnrval = zeros(8,1);
jpeg_c_rate = zeros(8,1);
jpeg_read = zeros(size(im,1),size(im,2),8);
for Qf = QP
    counter = (Qf-1)/14+1;
    imwrite(im,['jpegLena_QP' num2str(Qf) '.jpg'],'jpg','Quality',Qf);
    jpeg_read(:,:,counter) = imread(['jpegLena_QP' num2str(Qf) '.jpg']);
    jpeg_psnrval(counter) = psnr(uint8(jpeg_read(:,:,counter)), im);
    jpeg_c_rate(counter) = 8*fsize(['jpegLena_QP' num2str(Qf) '.jpg'])/numel(im);
end
disp('jpeg_c_rate');disp(jpeg_c_rate);
disp('jpeg_psnrval');disp(jpeg_psnrval);
figure('Name','PSNR vs Rate for QP = 1:14:99 Comparing JPEG and Arith07');
plot(jpeg_c_rate, jpeg_psnrval, '-rx',rate_N_16, psnrval_N_16, '-bx');title('PSNR v.s. Compression Rate');
xlabel('Rate (bpp)');
ylabel('PSNR (dB)');
legend({'JPEG','Arith07 (N = 16)'},'Location','northwest');
%% Task 3 (d) Compare JPEG and Arith07
%%
figure('Name','The first 4 comparison');colormap gray
for Qf = QP(1:4)
    counter = (Qf-1)/14+1;
    subplot(4,2,(counter-0.5)*2);
    imagesc(uint8(decoded_im_N_16(:,:,counter)));title(['Arith07 QP: ', num2str(Qf),...
        ', PSNR: ',num2str(psnr(uint8(decoded_im_N_16(:,:,counter)),im))]);
    subplot(4,2,counter*2);
    imagesc(jpeg_read(:,:,counter));title(['JPEG QP: ', num2str(Qf),...
        ', PSNR: ',num2str(psnr(uint8(jpeg_read(:,:,counter)),im))]);
end
figure('Name','The second 4 comparison');colormap gray
for Qf = QP(5:8)
    plot_counter = (Qf-1)/14-3;
    counter = (Qf-1)/14+1;
    subplot(4,2,(plot_counter-0.5)*2);
    imagesc(uint8(decoded_im_N_16(:,:,counter)));title(['Arith07 QP: ', num2str(Qf),...
        ', PSNR: ',num2str(psnr(uint8(decoded_im_N_16(:,:,counter)),im))]);
    subplot(4,2,plot_counter*2);
    imagesc(jpeg_read(:,:,counter));title(['JPEG QP: ', num2str(Qf),...
        ', PSNR: ',num2str(psnr(uint8(jpeg_read(:,:,counter)),im))]);
end
%% Task 3 (e)
%%
[psnrval_N_8,rate_N_8,decoded_im_N_8] = my_rd_curve(im,8,1:14:99);
figure('Name','The old');
plot(rate_N_16,psnrval_N_16,'-bx',rate_N_8,psnrval_N_8,'-ro');
legend('N = 16','N = 8');title('Comparing PSNR v.s. Compression Rate Performance of N = 8 or 16');
xlabel('Compression Rate (dpp)');ylabel('PSNR (dB)');
%%
[psnrval_N_128,rate_N_128,decoded_im_128] = my_rd_curve(im,128,1:14:99);
[psnrval_N_256,rate_N_256,decoded_im_256] = my_rd_curve(im,256,1:14:99);
[psnrval_N_512,rate_N_512,decoded_im_512] = my_rd_curve(im,512,1:14:99);
%%
% plot the RD-curve for N values 8, 16, 128, 256, 512
figure('Name','The new');
plot(rate_N_512,psnrval_N_512,'-d',...
    rate_N_256,psnrval_N_256,'-s',...
    rate_N_128,psnrval_N_128,'-*',...
    rate_N_16,psnrval_N_16,'-x',...
    rate_N_8,psnrval_N_8,'-o');
legend('N = 512',...
    'N = 256',...
    'N = 128',...
    'N = 16',...
    'N = 8','Location','northwest');
title('Comparing PSNR v.s. Compression Rate Performance');
xlabel('Compression Rate (dpp)');ylabel('PSNR (dB)');