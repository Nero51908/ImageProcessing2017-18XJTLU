% Demonstration of parsing 512*512 matrix into 64*64 cell of 8*8 matrices
% this script is nearly impossible to run for a result.
figure('Name','Blocks');
lena = imread('lenna512.bmp');
output = my_divider(lena,8);% output is 64 * 64 cell
for counter = 1:64*64
    subplot(64,64,counter);
    imshow(output{counter});
end

