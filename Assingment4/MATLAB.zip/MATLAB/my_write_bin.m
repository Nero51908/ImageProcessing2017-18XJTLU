function my_write_bin(input,file_name)
    target = fopen(file_name,'w');
    fwrite(target,input,'uint8');
    fclose(target);
end