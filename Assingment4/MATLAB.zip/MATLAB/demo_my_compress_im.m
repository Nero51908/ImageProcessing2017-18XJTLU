%% Image compression demo
% im is the input image
% qmat is 
% N is block size
% divide M*M matrix in to (M/N)*(M/N) blocks of N*N matrices (cells)
%%function
image_blocks = my_divider(im,N);% WARNING: cell type
% placeholder
dct_image_blocks = image_blocks;% WARNING: cell type
eq_dct_image_blocks = image_blocks;% WARNING: cell type
%% Set quality factor 
S = my_quality(QP);
%% 2d-dct and quatize
for blockNum = 1:numel(dct_image_blocks)
    %calculate 2D dct % WARNING: cell type
    dct_image_blocks{blockNum} = dct2(image_blocks{blockNum});
    %calculate equalized 2D dct % WARNING: cell type
    eq_dct_image_blocks{blockNum} = round(dct_image_blocks{blockNum}./(S*Qmat));
end
%% cell to mat
dct_image_blocks_mx = cell2mat(dct_image_blocks); %type conversion cell => vect
eq_dct_image_blocks_mx = cell2mat(eq_dct_image_blocks); %type conversion cell => vect
%% plot
figure;
colormap gray
indexing = 1 + (0:size(dct_image_blocks,1)-1)*N;
subplot(2,2,1);imagesc(dct_image_blocks_mx);title('DCT Matrix');
subplot(2,2,2);imagesc(eq_dct_image_blocks_mx);title('Quantized DCT Matrix');
subplot(2,2,3);imagesc(dct_image_blocks_mx(indexing,indexing));title('Rearrange DCT Matrix');
subplot(2,2,4);imagesc(eq_dct_image_blocks_mx(indexing,indexing));title('Rearrange Quantized DCT Matrix');
%% arithmetic encoding (entropy encoding)
if ~exist(file_name)
    ar_coded_vec = entropy_enc(eq_dct_image_blocks_mx);
    my_write_bin(ar_coded_vec,file_name);
    target = fopen(file_name,'w');
    fwrite(target,ar_coded_vec,'uint8');
    fclose(target);
else
    disp(['File named as "' file_name '" exists already, encoded vector is not saved.']);
end
%% evaluate rate
rate = fsize(file_name)/numel(im);