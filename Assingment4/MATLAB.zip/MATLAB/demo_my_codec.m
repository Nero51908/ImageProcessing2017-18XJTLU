%% demo my codec
demo_initialization;
%% compression
demo_my_compress_im;
%% decompression
demo_my_decompress_im;