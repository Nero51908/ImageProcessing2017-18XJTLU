function vct_out = entropy_dec(vct_in)

varargout = Arith07(vct_in);

vct_out = varargout;

return
