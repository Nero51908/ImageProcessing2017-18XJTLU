This is the coding dir of MATLAB code for Lab 4 (EEE 330 2017/18)

When checking the results of the code, you could run matlab live script file Lab4_image_compression_v2.mlx
This file will demo compression and decoding functions as required in task 1 and 2 of the lab session
Then it will perform experiments (evaluations) as Task 3 specifies. Lab tasks are specified by Assignment4-noQuiz.pdf in the same dir as this readme.

In this dir, you can find output files (images and binary coded vectors) of a complete run of Lab4_image_compression_v2.mlx.

By design, my_compress_im function will check whether the targeted file (of the same file name) exists or not.
If the file exists, the function will skip entropy encoding and file saving and display which file name has already been in the dir.

Thank you for viewing readme.