%% demo initialization
%% Parameters settings
QP = 99;
N = 16; 
Qmat = my_quantimx_gen(N);
file_name = 'demo_ar';
im = imresize(imread('lenna512.bmp'),1);% size of im is 128*128
%% run im compression first.
