function output = my_read_bin(file_name)
    target = fopen(file_name,'r');
    output = fread(target);
    fclose(target);
end