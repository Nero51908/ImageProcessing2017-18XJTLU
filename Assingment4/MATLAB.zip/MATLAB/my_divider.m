function output = my_divider(input,N)
inputSize = size(input);
output = mat2cell(input,ones(inputSize(1)/N,1)*N,ones(inputSize(2)/N,1)*N);
end