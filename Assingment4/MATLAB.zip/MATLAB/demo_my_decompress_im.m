%% Image Decompression Demo
%% read compressed image
code_vec = my_read_bin(file_name);
%% decompression using entropy_dec
dcomp_vec = cell2mat(entropy_dec(code_vec));% WARNING type conversion cell => vec
%% parse the d_comp_im to be 512 512, they are dct components
dcomp_dct_mx = reshape(dcomp_vec,[sqrt(length(dcomp_vec)),sqrt(length(dcomp_vec))]);
%% quality factor
S = my_quality(QP);
%% 2D IDCT
dcomp_dct_blocks = my_divider(dcomp_dct_mx,N);% blocks is of cell type
% placeholder
idct_blocks = dcomp_dct_blocks;
ueq_blocks = dcomp_dct_blocks;
for blockNum = 1:numel(dcomp_dct_blocks)
    ueq_blocks{blockNum} = dcomp_dct_blocks{blockNum}.*(S*Qmat);
    idct_blocks{blockNum} = idct2(ueq_blocks{blockNum});
end
%% output
demo_imo = cell2mat(idct_blocks);
imo_im_psnr = psnr(uint8(demo_imo),im);
figure;colormap gray
subplot(1,2,1);imagesc(demo_imo);title(['Decoded Image, QP: ', num2str(QP),', PSNR: ',num2str(imo_im_psnr)]);
subplot(1,2,2);imagesc(im);title('Original Image');