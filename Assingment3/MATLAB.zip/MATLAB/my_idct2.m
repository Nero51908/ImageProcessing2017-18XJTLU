function output = my_idct2(im_DCT,DCT_bases)
DCT_vec(1,1,:) = im_DCT(:);
output = sum(DCT_bases.*DCT_vec,3);
end