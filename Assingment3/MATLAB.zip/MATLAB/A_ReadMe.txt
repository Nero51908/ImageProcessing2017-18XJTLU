All MATLAB code files in this folder are written and tested in MATLAB 2018a.
To see the lab procedure, please open livescript file Lab3_imageTransform_ver2.mlx
All user defined functions have names starting with "my_".
Pictures saved from MATLAB Figures are also in this dir. They are the same images
as shown in the .pdf report file.