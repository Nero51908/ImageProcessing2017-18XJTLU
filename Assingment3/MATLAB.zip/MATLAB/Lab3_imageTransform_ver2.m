%% LAB3 Image Transform

%% Task 1
% a)
x = 1:256;
figure;plot(x);title('Original x');
% b)
pts = 192;
dft_x = fft(x);
dct_x = dct(x);
% original DFT and DCT plot
figure; plot(fftshift(abs(dft_x)));title('DFT of x (magnitude)');
figure; plot(dct_x);title('DCT of x');
% filtering
    LPF_dft_x = my_1D_LPF_FFT(dft_x,pts);
    LPF_dct_x = my_1D_LPF_DCT(dct_x,pts);
    figure;
    subplot(2,2,1); plot(abs(LPF_dft_x));title(['LPF: ' num2str(pts/256*100) '% DFT frequency components are suppressed']);
    subplot(2,2,2); plot(LPF_dct_x);title(['LPF: ' num2str(pts/256*100) '% DCT frequency components are suppressed']);
    subplot(2,2,3); plot(abs(ifft(LPF_dft_x)));title('LPF (DFT) filtered x in spatial domain');
    subplot(2,2,4); plot(idct(LPF_dct_x));title('LPF (DCT) filtered x in spatial domain');
% c)
%psnr array place holder    
my_psnr_LPF_dft = zeros(1,7);
my_psnr_LPF_dct = zeros(1,7);
figure;
for pts = 32:32:224
    LPF_dft_x = my_1D_LPF_FFT(dft_x,pts);
    LPF_dct_x = my_1D_LPF_DCT(dct_x,pts);
    subplot(7,2,(pts/32-1)*2 + 1); plot(abs(ifft(LPF_dft_x)));title([num2str(pts) ' pts LPF (DFT) filtered x in spatial domain']);
    subplot(7,2,pts/16); plot(idct(LPF_dct_x));title([num2str(pts) ' pts LPF (DCT) filtered x in spatial domain']);
    my_psnr_LPF_dft(pts/32) = my_psnr(abs(ifft(LPF_dft_x)),x);
    my_psnr_LPF_dct(pts/32) = my_psnr(abs(idct(LPF_dct_x)),x);
end
%% Task 2
% please NOTE that the variable x has been over written after the beginning 
% of this task.
%%
% a)
width = 256; N=width/16; n=(1:width)-1; x = 1+cos(2*pi*n/N);
im = ones(width, 1)*x; im_a = im;
figure;imshow(im);title('im for (a) and (b)');
% b)
DFT2_im_b = fft2(im);
figure;subplot(1,2,1);imshow(log10(abs(DFT2_im_b)));title('magnitude of 2d dft of im');
subplot(1,2,2);imshow(log10(abs(fftshift(DFT2_im_b))));title('magnitude of shifted 2d dft of im');
% c)
N=width/8;x = 1+cos(2*pi*n/N);
im = ones(width, 1)*x;
DFT2_im_c = fft2(im);
figure;
subplot(1,2,1);imshow(im_a);title('im for (a) and (b)');
subplot(1,2,2);imshow(im);title('im redefined by (c)');
figure;
subplot(1,2,1);imshow(log10(abs(DFT2_im_b)));title('(b) magnitude of 2d dft of im');
subplot(1,2,2);imshow(log10(abs(DFT2_im_c)));title('(c) magnitude of 2d dft of im');
figure;
subplot(1,2,1);imshow(log10(abs(fftshift(DFT2_im_b))));title('(b) magnitude of shifted 2d dft of im');
subplot(1,2,2);imshow(log10(abs(fftshift(DFT2_im_c))));title('(c) magnitude of shifted 2d dft of im');
% d)
% recover N from (a)
N=width/16
x = 1+cos(2*pi*n/N)+ cos(4*pi*n/N);
im = ones(width, 1)*x;
figure;
subplot(1,2,1);imshow(im_a);title('im from (a)');
subplot(1,2,2);imshow(im);title('im from (d)');
DFT2_im = fft2(im);
figure;
subplot(1,2,1);imshow(log10(abs(DFT2_im_b)));title('(b) magnitude of 2d dft of im');
subplot(1,2,2);imshow(log10(abs(DFT2_im)));title('(d) magnitude of 2d dft of im');
figure;
subplot(1,2,1);imshow(log10(abs(fftshift(DFT2_im_b))));title('(b) magnitude of shifted 2d dft of im');
subplot(1,2,2);imshow(log10(abs(fftshift(DFT2_im))));title('(d) magnitude of shifted 2d dft of im');
%% Task 3
%%
fence = imread('fence.jpg');
% WARNING fence has 3 layers.
figure;imshow(fence);
fft2_fence=fftshift(fft2(fence(:,:,1)));
figure;
imagesc(log10(abs(fft2_fence)));colorbar;title('2D-DFT of the first layer of fence.jpg')
mask_horiz = my_stripe_maskMaker_ver2(size(fence(:,:,1)),'horiz',6,12,250,0);
mask_verti = my_stripe_maskMaker_ver2(size(fence(:,:,1)),'verti',6,13,150,0);
% test filtering
filter = mask_verti.*mask_horiz;%.*mask_dash;
demo_mask_horiz = my_stripe_maskMaker_ver2(size(fence(:,:,1)),'horiz',30,12,250,0);
demo_mask_verti = my_stripe_maskMaker_ver2(size(fence(:,:,1)),'verti',50,13,150,0);
demo_filter = demo_mask_verti.*demo_mask_horiz;%.*mask_dash;
figure;
subplot(1,2,1);imshow(demo_mask_horiz .* demo_mask_verti);axis on;
subplot(1,2,2);mesh(demo_filter);title('Filter shape demonstration');colorbar;axis on;
fft_fence_out_LPF2 = mask_verti.*mask_horiz .* fft2_fence;
fft_graylevel = 2*mean(mean(abs(fft_fence_out_LPF2)));
% particular solution
%mask_dash = my_stripe_maskMaker_ver3(size(fence(:,:,1)),'v',6,13,150,0,235);
% line y = 6.3529x + (-1561.8);
mask_dash = ones(size(fence(:,:,1)));
anchorshift = repelem((0:6)',1,(328-260+1));
x_values = 260:328;
y_values = ceil(6.3529*x_values - 1561.8);
x_anchors = repelem(x_values,7);
y_anchors = repelem(y_values,7) + anchorshift(:)';
anchors = [x_anchors;y_anchors];
for vind = 1:length(x_anchors)
        % y x
        mask_dash(anchors(2,vind),anchors(1,vind)) = 0;
    
end
for cycle = (1:5) - 3
    mask_dash = mask_dash .* circshift(mask_dash,cycle,2) .* circshift(mask_dash,1,1);
end
mask_dash = my_pass_filterMIXER(size(mask_dash),mask_dash,15,250);
output = mask_dash .* fft_fence_out_LPF2; % mask_verti.*mask_horiz .* fft2_fence;
figure;
subplot(2,3,1);imshow(fence);title('Original Image');
subplot(2,3,2);imshow(uint32(abs(fft_fence_out_LPF2)),gray(fft_graylevel));title('Filtered Frequency Domain');
subplot(2,3,3);imshow(uint8(abs(ifft2(ifftshift(fft_fence_out_LPF2)))));title('Filtered Image');
subplot(2,3,4);imshow(fence);title('Original Image');
subplot(2,3,5);imshow(uint32(abs(output)),gray(fft_graylevel));title('Improved filter Frequency Domain');
subplot(2,3,6);imshow(uint8(abs(ifft2(ifftshift(output)))));title('Filtered Image');

%% Task 4 Image Resizing Using Zero Padding (In Frequency Domain)
%%
%im420 zeropadding
im420 = imread('../Lab 3 material/lenna_ds420.bmp');
im420_512_512 = my_zeropadding_resize(im420,[512, 512]);
%im440 zeropadding
im440 = imread('../Lab 3 material/lenna_ds440.bmp');
im440_512_512 = my_zeropadding_resize(im440,[512, 512]);
%% psnr
%%

im = imread('../Lab 3 material/lenna512.bmp');
psnr_im420_512_512_im = my_psnr(im420_512_512,im);
disp(['Zero-padding: im420_512_512, im: ' num2str(psnr_im420_512_512_im)]);
psnr_im440_512_512_im = my_psnr(im440_512_512,im);
disp(['Zero-padding: im440_512_512, im: ' num2str(psnr_im440_512_512_im)]);
%imresize nearest
m_im420_512_512_n = imresize(im420,[512 512],'nearest');
psnr_m_im420_512_512_n_im = my_psnr(m_im420_512_512_n,im);
disp(['imresize: m_im420_512_512_n, im: (nearest)' num2str(psnr_m_im420_512_512_n_im)]);
m_im440_512_512_n = imresize(im440,[512 512],'nearest');
psnr_m_im440_512_512_n_im = my_psnr(m_im440_512_512_n,im);
disp(['imresize: m_im440_512_512_n, im: (nearest)' num2str(psnr_m_im440_512_512_n_im)]);
%imresize lanczos3
m_im420_512_512_l = imresize(im420,[512 512],'lanczos3');
psnr_m_im420_512_512_l_im = my_psnr(m_im420_512_512_l,im);
disp(['imresize: m_im420_512_512_n, im: (lanczos3)' num2str(psnr_m_im420_512_512_l_im)]);
m_im440_512_512_l = imresize(im440,[512 512],'lanczos3');
psnr_m_im440_512_512_l_im = my_psnr(m_im440_512_512_l,im);
disp(['imresize: m_im440_512_512_n, im: (lanczos3)' num2str(psnr_m_im440_512_512_l_im)]);
%% compare
%%
figure;
subplot(3,2,1);imshow(im420_512_512);title(['im420\_512\_512 Zero-padding, PSNR: ' num2str(psnr_im420_512_512_im)]);
subplot(3,2,2);imshow(im440_512_512);title(['im440\_512\_512 Zero-padding, PSNR: ' num2str(psnr_im440_512_512_im)]);
subplot(3,2,3);imshow(m_im420_512_512_n);title(['im420\_512\_512 nearest, PSNR: ' num2str(psnr_m_im420_512_512_n_im)]);
subplot(3,2,4);imshow(m_im440_512_512_n);title(['im440\_512\_512 nearest, PSNR: ' num2str(psnr_m_im440_512_512_n_im)]);
subplot(3,2,5);imshow(m_im420_512_512_l);title(['im420\_512\_512 lanczos3, PSNR: ' num2str(psnr_m_im420_512_512_l_im)]);
subplot(3,2,6);imshow(m_im440_512_512_l);title(['im440\_512\_512 lanczos3, PSNR: ' num2str(psnr_m_im440_512_512_l_im)]);
%% Task 5 a) 4 by 4 Bases Generation
%%
[im_DCT, DCT_bases] = my_projection_an_image_on_its_DCT_bases(ones(4));
%% Task 5 b) Apply DCT to figures
%%
fig3(:,:,1) = [ones(4,1) zeros(4,3)];
fig3(:,:,2) = [zeros(1,4);ones(1,4);zeros(2,4)];
fig3(:,:,3) = eye(4);
[fig3_i_DCT, DCT_bases_i] = my_projection_an_image_on_its_DCT_bases(fig3(:,:,1));
[fig3_ii_DCT, DCT_bases_ii] = my_projection_an_image_on_its_DCT_bases(fig3(:,:,2));
[fig3_iii_DCT, DCT_bases_iii] = my_projection_an_image_on_its_DCT_bases(fig3(:,:,3));
m_fig3_i_DCT = dct2(fig3(:,:,1));
m_fig3_ii_DCT = dct2(fig3(:,:,2));
m_fig3_iii_DCT = dct2(fig3(:,:,3));
figure('Color',[1 1 0.8])
colormap(gray);
subplot(3,3,1);imagesc(fig3(:,:,1));title('(i)');axis square;colorbar
subplot(3,3,2);imagesc(fig3_i_DCT);title('im\_DCT of (i)');axis square;colorbar
subplot(3,3,3);imagesc(m_fig3_i_DCT);title('MATLAB DCT2');axis square;colorbar
subplot(3,3,4);imagesc(fig3(:,:,2));title('(ii)');axis square;colorbar
subplot(3,3,5);imagesc(fig3_ii_DCT);title('im\_DCT of (ii)');axis square;colorbar
subplot(3,3,6);imagesc(m_fig3_ii_DCT);title('MATLAB DCT2');axis square;colorbar
subplot(3,3,7);imagesc(fig3(:,:,3));title('(iii)');axis square;colorbar
subplot(3,3,8);imagesc(fig3_iii_DCT);title('im\_DCT of (iii)');axis square;colorbar
subplot(3,3,9);imagesc(m_fig3_iii_DCT);title('MATLAB DCT2');axis square;colorbar
%% Task 5 c) inverse DCT
%%
IDCT_fig3_i_DCT = my_idct2(fig3_i_DCT, DCT_bases_i);
IDCT_fig3_ii_DCT = my_idct2(fig3_ii_DCT, DCT_bases_ii);
IDCT_fig3_iii_DCT = my_idct2(fig3_iii_DCT, DCT_bases_iii);
figure('Color',[1 1 0.8])
colormap(gray);
subplot(3,3,1);imagesc(fig3(:,:,1));title('(i)');axis square ;colorbar
subplot(3,3,2);imagesc(fig3_i_DCT);title('im\_DCT of (i)');axis square;colorbar
subplot(3,3,3);imagesc(IDCT_fig3_i_DCT);title('2D Inverse DCT');axis square;colorbar
subplot(3,3,4);imagesc(fig3(:,:,2));title('(ii)');axis square;colorbar
subplot(3,3,5);imagesc(fig3_ii_DCT);title('im\_DCT of (ii)');axis square;colorbar
subplot(3,3,6);imagesc(IDCT_fig3_ii_DCT);title('2D Inverse DCT');axis square;colorbar
subplot(3,3,7);imagesc(fig3(:,:,3));title('(iii)');axis square;colorbar
subplot(3,3,8);imagesc(fig3_iii_DCT);title('im\_DCT of (iii)');axis square;colorbar
subplot(3,3,9);imagesc(IDCT_fig3_iii_DCT);title('2D Inverse DCT');axis square;colorbar