    function output = my_1D_LPF_FFT(input,pts) % 1D LPF
    % pts should be even
    % note that fftshift is applied to input here
    % there is no need to perform ifftshift to the output before applying ifft to output
        input = fftshift(input);
        output = [zeros([1,pts/2]), input((pts/2+1):(end-pts/2)), zeros([1,pts/2])];
    end
