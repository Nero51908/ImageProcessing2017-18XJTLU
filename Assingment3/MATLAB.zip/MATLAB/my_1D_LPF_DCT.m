    function output = my_1D_LPF_DCT(input,pts)
        output = [input(1:(end-pts)), zeros([1,pts])];
    end
