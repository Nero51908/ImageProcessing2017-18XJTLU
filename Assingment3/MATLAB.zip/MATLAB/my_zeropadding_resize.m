function output = my_zeropadding_resize(input,targetSize)
fft_input = fftshift(fft2(input));
fft_target = my_zeropadding(fft_input,targetSize);
ifft_fft_target = ifft2(ifftshift(fft_target));
output = uint8(numel(ifft_fft_target)/numel(input)*abs(ifft_fft_target));
%output = abs(ifft_fft_target);
fft_graylevel = 2*mean(mean(abs(fft_input)));
%
figure;
subplot(2,2,1);imshow(input);title(['Input Image, Size: ' num2str(size(input))]);
subplot(2,2,2);imshow(abs(fft_input),gray(fft_graylevel));title('Frequency Domain Representation of Input');
subplot(2,2,4);imshow(abs(fft_target),gray(fft_graylevel));title('After Zero-padding');
subplot(2,2,3);imshow(output);title(['Resized Input Image, Size: ' num2str(size(output))]);
figure;imshow(output);title(['Resized Input Image Size: ' num2str(size(output))]);
end
function output = my_zeropadding(input,targetSize)
% input is a image
% target size is the size of the output image
% argument check
if size(input) >= targetSize
    disp('please check: targetSize should be larger than the size of the input image in both dimenssions');
    return
end
inputSize = size(input);
% width is the width in terms of "points" of padded zeros for each of the
% edges. l_r stands for left and right, t_b stands for top and bottom
width_l_r_l = ceil((targetSize(2) - inputSize(2))/2);
width_l_r_r = floor((targetSize(2) -inputSize(2))/2);
width_t_b_t = ceil((targetSize(1) - inputSize(1))/2);
width_t_b_b = floor((targetSize(1) -inputSize(1))/2);
output = cat(1,zeros([width_t_b_t,targetSize(2)]),cat(2,zeros([inputSize(1),width_l_r_l]),input,zeros([inputSize(1),width_l_r_r])),zeros([width_t_b_b,targetSize(2)]));
end