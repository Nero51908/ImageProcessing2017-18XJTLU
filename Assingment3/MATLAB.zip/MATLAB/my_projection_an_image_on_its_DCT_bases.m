function [im_DCT, DCT_bases] = my_projection_an_image_on_its_DCT_bases(im)
im_size = size(im);
% 1 N vertical axis , 2 M horizontal axis
%   k                   L
% real part is l, imag part is k WARNING IDCT need to follow this order
kl_stack = (ones([im_size(1),1])*(0:(im_size(2)-1))) + 1i*((0:(im_size(1)-1))'*ones([1,im_size(2)]));
% place holder
DCT_bases = zeros([im_size(1),im_size(2),numel(im)]);
n_21_pi = ((0:im_size(1)-1)*2 + 1)*pi;
m_21_pi = ((0:im_size(2)-1)*2 + 1)*pi;
% subplot position
position = vec2mat(1:numel(im),im_size(2));
position = position(:);
figure('Color',[1 1 0.8]);
for level = 1:numel(im)
    colormap(gray);
    al = (real(kl_stack(level)) == 0) * sqrt(1/im_size(1)) + (real(kl_stack(level)) ~= 0) * sqrt(2/im_size(1));
    ak = (imag(kl_stack(level)) == 0) * sqrt(1/im_size(2)) + (imag(kl_stack(level)) ~= 0) * sqrt(2/im_size(2));
    %                   k                                   l
    DCT_bases(:,:,level) =  ak*al*(((cos((n_21_pi*imag(kl_stack(level)))/(2*im_size(1))))'*ones([1,im_size(2)])).* (ones([im_size(1),1])*cos((m_21_pi*real(kl_stack(level)))/(2*im_size(2)))));
    subplot(im_size(1),im_size(2),position(level));
    imagesc(DCT_bases(:,:,level));
    axis square
    colorbar
end
im_DCT = sum(sum(im.*DCT_bases));
im_DCT = vec2mat(im_DCT(:) ,im_size(1)).';
% end of function
end