function mask = my_stripe_maskMaker_ver3(maskSize,direction,stripeWidth, LP_radius,HP_radius,centerOffset,slider)  
    maskCenter = [ceil(maskSize(1)/2),ceil(maskSize(2)/2)];
    %placeholer
    mask = zeros(maskSize);
% 2d filter generation
    % imagine part
    imaginary = 1i*((maskSize(1):-1:1)-maskCenter(1)-1+centerOffset)'.*ones([1,maskSize(2)]);
    % real part
    real_axis = ((1:maskSize(2))-maskCenter(2)+centerOffset).*ones([maskSize(1),1]);
    % complex
    complex = real_axis+imaginary;
    circular = abs(complex);
    LP_circle =  circular<(LP_radius);
    HP_circle = circular>(HP_radius);
% data Removing strip generation (only one stripe)
    % line equation
    if slider == 0 
        if direction == 'vertical'
            mask = logical(LP_circle + HP_circle + cat(2,ones(maskSize(1),ceil((maskSize(2)-stripeWidth)/2)+centerOffset),zeros(maskSize(1),stripeWidth),ones(maskSize(1),floor((maskSize(2)-stripeWidth)/2)-centerOffset)));
        elseif direction == 'horizontal'
            mask = logical(LP_circle + HP_circle + cat(1,ones(ceil((maskSize(1)-stripeWidth)/2)+centerOffset,maskSize(2)),zeros(stripeWidth,maskSize(2)),ones(floor((maskSize(1)-stripeWidth)/2)-centerOffset,maskSize(2))));
        end
    else % lines that are not parallel to any of the axes
        
    end
       