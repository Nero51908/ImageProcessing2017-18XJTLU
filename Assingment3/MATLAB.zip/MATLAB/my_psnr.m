function output = my_psnr(input,reference)
% check whether the input matrix is of the same size as reference matrix
if size(input) ~= size(reference)
    %if not, print error message and return to command line
    disp('input error: inconsistant image size');
    return
end
%recognize input type:how many gray levels
if ~isa(input,'double')
    R = diff(getrangefromclass(reference));
else
    R = max(max(reference));
%end of conditions
end
%covert uint type to double type for noninteger values
%without such type conversion, the formula of PSNR won't work because
%values are converted to be integer by the type of uint during the
%calculation of PSNR.
input = double(input);
reference = double(reference);
%calculate MSE which is not necessarily an integer.
MSE = sum(sum((input-reference) .^ 2))/numel(input);
%calculate PSNR using definition.
output = 10 * log10(R^2 / MSE);
%end of function
end
