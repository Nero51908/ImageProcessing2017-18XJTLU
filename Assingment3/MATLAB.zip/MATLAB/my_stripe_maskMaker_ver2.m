function output = my_stripe_maskMaker_ver2(inputSize,direction,width,LP_radius,HP_radius,position)
% inputSize is the output mask inputSize
% direction can be 'horiz' (--) or 'verti' (|)
% width of stripe which zeros out covered components in 2D fft plain
% LP_radius is the width of low-pcenteringass components
% HP_radius is the width to keep high frequency components
% position is "where to place this removing stripe"
%   for horiz, this position means row
%   for verti, this position means column
%
% build mask
if direction == 'horiz'
    inputCheck(LP_radius,inputSize);
    output = maskMaker(inputSize,width,position,LP_radius,HP_radius);
elseif direction == 'verti'
    inputSize = fftshift(inputSize);
    inputCheck(LP_radius,inputSize);
    output = maskMaker(inputSize,width,position,LP_radius,HP_radius)';
else, disp('wrong direction input'); return;
end
end
% input check
function returnValue = inputCheck(LP_radius,inputSize)
if mod(inputSize(2)+LP_radius,2)
    disp(['WARNING: LP_radius should be an integer of the same parity property as ' num2str(inputSize(2))]);
    returnValue = 0;
    return;
end
end
%make a mask
function mask = maskMaker(inputSize,width,position,LP_radius,HP_radius)
% stripe = [ones([width,HP_radius]),zeros([width,ceil((inputSize(2)-LP_radius-2*HP_radius)/2)]),...
%     ones([width,LP_radius]),zeros([width,floor((inputSize(2)-LP_radius-2*HP_radius)/2)]),...
%     ones([width,HP_radius])];

	stripe = zeros([width,inputSize(2)]);
    %
    % imagine part
    imaginary = 1i*((inputSize(1):-1:1)-floor(inputSize(1)/2)+position)'.*ones([1,inputSize(2)]);
    % real part
    real = ((1:inputSize(2))-floor(inputSize(2)/2)+position).*ones([inputSize(1),1]);
    % complex
    complex = real+imaginary;
    circular = abs(complex);
    LP_circle =  circular<(LP_radius);
    HP_circle = circular>(HP_radius);
    removing_filter = cat(1,ones([ceil((inputSize(1)-width)/2)+position,inputSize(2)]),stripe,ones([floor((inputSize(1)-width)/2)-position,inputSize(2)]));
    mask = logical(LP_circle + HP_circle + removing_filter);
    figure;
    subplot(1,2,1);imshow(LP_circle);title('LPF');
    subplot(1,2,2);imshow(HP_circle);title('HPF');
end

