function output = my_zeropadding(input,targetSize)
% input is a image
% target size is the size of the output image
% argument check
if size(input) >= targetSize
    disp('please check: targetSize should be larger than the size of the input image in both dimenssions');
    return
end
inputSize = size(input);
% width is the width in terms of "points" of padded zeros for each of the
% edges. l_r stands for left and right, t_b stands for top and bottom
width_l_r_l = ceil((targetSize(2) - size(input,2))/2);
width_l_r_r = floor((targetSize(2) -size(input,2))/2);
width_t_b_t = ceil((targetSize(1) - size(input,1))/2);
width_t_b_b = floor((targetSize(1) -size(input,1))/2);
output = cat(1,zeros([width_t_b_t,targetSize(2)]),cat(2,zeros([inputSize(1),width_l_r_l]),input,zeros([inputSize(1),width_l_r_r])),zeros([width_t_b_b,targetSize(2)]));
end