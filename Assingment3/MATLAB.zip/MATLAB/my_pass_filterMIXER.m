function output = my_pass_filterMIXER(inputSize,removing_filter,LP_radius,HP_radius)
imaginary = 1i*((inputSize(1):-1:1)-floor(inputSize(1)/2))'.*ones([1,inputSize(2)]);
    % real part
    real = ((1:inputSize(2))-floor(inputSize(2)/2)).*ones([inputSize(1),1]);
    % complex
    complex = real+imaginary;
    circular = abs(complex);
    LP_circle =  circular<(LP_radius);
    HP_circle = circular>(HP_radius);
    output = logical(LP_circle + HP_circle + removing_filter);
end