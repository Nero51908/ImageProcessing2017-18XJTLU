function output = my_detect_car_license_plate_v2(im,letter_template,letter_contour,number_template,number_contour)
%%%%% function part below
% im contains the content of plate to be detected. Keep the Chinese
% Character for this version 2 implementation.
% letter_template must be multidimentional array of size: 92,104,26
% input for this lab should be thin_letter
% number_template must be multidimentional array of size: 90,89,10
% input for this lab should be thin_number
%% ouput base:
letterstring = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
numberstring = '0123456789';
%% detection
% initialization and place holder
% 8 positions, 26 possible detection results for each position
letter_candidates = zeros(8,26);
% 8 positions, 10 possible detection results for each position
number_candidates = zeros(8,10);
% detect connected objects
CC = bwconncomp(im);
% CC can be used to select character
%% letter detection using bwhitmiss
for position = (1:8)+4
    % change position every time
    plate = zeros(size(im));
    plate(CC.PixelIdxList{position})=1;
    for numberposition = 1:26
    hm_plate = bwhitmiss(plate,letter_template(:,:,numberposition),letter_contour(:,:,numberposition));
    hm_plate = bwareafilt(hm_plate,[1 40]);
    if sum(sum(hm_plate))
           letter_candidates(position-4,numberposition) = 1;
    end
    end
end
%% number detection using bwhitmiss
for position = 9
    % change position every time
    plate = zeros(size(im));
    plate(CC.PixelIdxList{position})=1;
    for numberposition = 1:10
    hm_plate = bwhitmiss(plate,number_template(:,:,numberposition),number_contour(:,:,numberposition));
    if sum(sum(hm_plate))
       number_candidates(position-4,numberposition) = 1;
    end
    end
end
%% output
for position = find(sum(letter_candidates,2))'
   output(position) = letterstring(find(letter_candidates(position,:)));
end
% number:
for position = find(sum(number_candidates,2))'
   output(position) = numberstring(find(number_candidates(position,:)));
end
end