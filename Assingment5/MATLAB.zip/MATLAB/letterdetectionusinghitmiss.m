%% letter detection using bwhitmiss
for position = 1:8
    % change position every time
    plate = zeros(size(im));
    plate(CC.PixelIdxList{position})=1;
    for numberposition = 20
        hm_plate = bwhitmiss(plate,letter_template(:,:,numberposition));
        % recover Inf values caused by didlation
        hm_plate(:,[1:30,458:end]) = false;
        sum(sum(hm_plate))
        figure;imshow(hm_plate);
%         if sum(sum(hm_plate))-sum(sum(letter_template(:,:,numberposition)))>90
%             letter_candidates(position,numberposition) = 1;
%         end
    end
end