function output = my_detect_car_license_plate_v1(im,letter_template,number_template)
%%%%% function part below
% im contains the content of plate to be detected. 
% im must be of size 81,465
% letter_template must be multidimentional array of size: 92,104,26
% input for this lab should be thin_letter
% number_template must be multidimentional array of size: 90,89,10
% input for this lab should be thin_number
%% ouput base:
letterstring = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
numberstring = '0123456789';
%% detection
% initialization and place holder
% 8 positions, 26 possible detection results for each position
letter_candidates = zeros(8,26);
% 8 positions, 10 possible detection results for each position
number_candidates = zeros(8,10);

% detect connected objects
CC = bwconncomp(im);
% CC can be used to select character
%% letter detection
for position = 1:8
    % change position every time
    plate = zeros(size(im));
    plate(CC.PixelIdxList{position})=1;
    % figure;imshow(plate);
    % letter detection
    for numberposition = 3:26
%       disp(['CurrentPosition ' num2str(position) ' , ' num2str(numberposition)]);
        e_plate = imopen(plate,letter_template(:,:,numberposition));
        % recover Inf values caused by didlation
        e_plate(abs(e_plate)==Inf) = 0;
%         disp(['target/template difference: ' num2str(abs(sum(sum(e_plate))-sum(sum(letter_template(:,:,numberposition)))))]);
%         figure;
%         subplot(1,2,1);imshow(e_plate);title(['e\_plate at position' num2str(position) 'number of white pix: ' num2str(sum(sum(e_plate)))]);
%         subplot(1,2,2);imshow(letter_template(:,:,numberposition));title(['template at numberposition: ' num2str(numberposition) 'number of white pix: ' num2str(sum(sum(letter_template(:,:,numberposition))))]);
%         disp(['Reason for hit: ' num2str(sum(sum(e_plate))-sum(sum(letter_template(:,:,numberposition)))>90)]);
        if sum(sum(e_plate))-sum(sum(letter_template(:,:,numberposition)))>90
%             disp(['Hit Position ' num2str(position) ' , ' num2str(numberposition)]);
%             disp(['Reason for hit: ' num2str(sum(sum(e_plate))-sum(sum(letter_template(:,:,numberposition)))>90)]);
%             figure;subplot(1,2,1);imshow(e_plate);subplot(1,2,2);imshow(letter_template(:,:,numberposition));title('Compare target and template');
            letter_candidates(position,numberposition) = 1;
        end
    end
end
%% number detection
for position = 1:8
    % change position every time
    plate = zeros(size(im));
    plate(CC.PixelIdxList{position})=1;
    % figure;imshow(plate);
    % letter detection
    for numberposition = 1:10
        e_plate = imerode(plate,number_template(:,:,numberposition));
        if sum(sum(e_plate))
            number_candidates(position,numberposition) = 1;
        end
    end
end
%% Specificly remove prefix characters 
% they are: E-F using F template , E-L using L template, O-C-Q using C template
% Q-O using O template and B-D-E-F-H-K-L-M-N-P-R-T-I using I template
% E-F means E.
% E-L means E.
% O-C-Q means C.
% O-C means O.
% C-Q means Q.
% O-Q means O.
trigger = 1;
while trigger == 1
    trigger = 0;
for position = 1:8
    % E-F at position = E
    if (letter_candidates(position,5) + letter_candidates(position,6)) == 2
        letter_candidates(position,6) = 0;trigger = 1;
    % E-L at position = E
    elseif (letter_candidates(position,5) + letter_candidates(position,12)) == 2
        letter_candidates(position,12) = 0;trigger = 1;
    end
    % O C Q at position = C
    if (letter_candidates(position,3) + letter_candidates(position,15) + letter_candidates(position,17)) == 3
        letter_candidates(position,15) = 0;
        letter_candidates(position,3) = 0;trigger = 1;
    % O-C at position = O
    elseif (letter_candidates(position,15) + letter_candidates(position,3) ) == 2
        letter_candidates(position,3) = 0;trigger = 1;
    % C-Q at position = Q
    elseif (letter_candidates(position,3) + letter_candidates(position,17) ) == 2
        letter_candidates(position,3) = 0;trigger = 1;
    % O-Q at position = Q
    elseif (letter_candidates(position,15) + letter_candidates(position,17) ) == 2
        letter_candidates(position,17) = 0;trigger = 1;
    end
end
end
%% logically remove wrongly detected characters
% for letters
letter_amb = sum(letter_candidates,2) > 1;
while sum(letter_amb)
   determined_positions = find(~letter_amb);
   undetermined_positions = find(letter_amb);
   %position_counter = 1;
   for position = undetermined_positions
        rectifier = sum(letter_candidates([determined_positions;position],:))>1;
        letter_candidates(position,rectifier) = 0;
        %position_counter = position_counter + 1;
   end
   letter_amb = sum(letter_candidates,2) > 1;
end
% for numbers
number_amb = sum(number_candidates,2) > 1;
while sum(number_amb)
   determined_positions = find(~number_amb);
   undetermined_positions = find(number_amb);
   for position = undetermined_positions
        rectifier = sum(number_candidates([determined_positions,position],:))>1;
        number_candidates(position,rectifier) = 0;
   end
   number_amb = sum(number_candidates,2) > 1;
end
%% output string gen
% place holder
output(8) = '0';
% number detection results covers the letter detection results
% letter:
for position = 1:8
   output(position) = letterstring(find(letter_candidates(position,:)));
end
% number:
for position = find(sum(number_candidates,2))'
   output(position) = numberstring(find(number_candidates(position,:)));
end
