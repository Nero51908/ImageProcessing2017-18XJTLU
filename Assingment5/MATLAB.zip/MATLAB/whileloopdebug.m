letter_amb = sum(letter_candidates,2) > 1;
while sum(letter_amb)
   determined_positions = find(~letter_amb);
   undetermined_positions = find(letter_amb);
   %position_counter = 1;
   for position = undetermined_positions
        rectifier = sum(letter_candidates([determined_positions;position],:))>1;
        letter_candidates(position,rectifier) = 0;
        %position_counter = position_counter + 1;
   end
   letter_amb = sum(letter_candidates,2) > 1;
end