%% Lab 5 Morphology
%% Task 1 
%% Step 1
% Show different layers of images and select the best layer for binarization.
%%
% load image
im_coins = imread('../Lab5 material/Coins.jpg');
% layers
im_coins_1 = im_coins(:,:,1);
im_coins_2 = im_coins(:,:,2);
im_coins_3 = im_coins(:,:,3);
im_coins_avg = uint8(mean(im_coins,3));
% show in RGB
figure;
subplot(4,1,1);imshow(im_coins_1);
subplot(4,1,2);imshow(im_coins_2);
subplot(4,1,3);imshow(im_coins_3);
subplot(4,1,4);imshow(im_coins_avg);
% hsv model conversion
hsv_im_coins = rgb2hsv(im_coins);
% show in hsv
figure;
subplot(4,1,1);imshow(hsv_im_coins);
subplot(4,1,2);imshow(hsv_im_coins(:,:,1));
subplot(4,1,3);imshow(hsv_im_coins(:,:,2));
subplot(4,1,4);imshow(hsv_im_coins(:,:,3));
% separated plot
figure;imshow(hsv_im_coins);
figure;imshow(hsv_im_coins(:,:,1));
figure;imshow(hsv_im_coins(:,:,2));
figure;imshow(hsv_im_coins(:,:,3));
% HSV second layer is better than any RGB layers
%% Step 2
% Binarize the image
%%
% threshold decision
% binarize using hsv layer 2
bin_im_coins = ~imbinarize(hsv_im_coins(:,:,2),0.7);
figure;imshow(bin_im_coins);
%% %Step 3 
% %remove small objects (clusters)
%%
%bin_im_coins = bwareaopen(bin_im_coins,1000,6);
%figure;imshow(bin_im_coins);
%% Step 3
% Set Structure Element
%%
% creating structure element (SE)
SE_e = strel('disk', 20);
SE_d = strel('disk', 60);
%% Step 4 
% Apply Opening Operation
%%
bin_im_coins = imopen(bin_im_coins,SE_d);
figure;imshow(bin_im_coins);
%% Step 5 
%     Apply erosion
%%
e_bin_im_coins = imerode(bin_im_coins,SE_e);
figure;imshow(e_bin_im_coins);
%% Step 6 
% Repeat erosion for 1 Time to Break All Connections between Clusters.
%%
e_bin_im_coins = imerode(e_bin_im_coins,SE_e);
figure;imshow(e_bin_im_coins);
%% Step 7 
% Count Connected Objects Using bwconnecomp (MATLAB Built-in Function)
%%
CC = bwconncomp(e_bin_im_coins);
disp(['The number of coins in image im_coins is '...
    num2str(CC.NumObjects) '.']);
%% Plots for Task 1
%%
step1 = hsv_im_coins(:,:,2);
step2 = ~imbinarize(hsv_im_coins(:,:,2),0.7);
step4 = imopen(bin_im_coins,SE_d);
step5 = imerode(step4,SE_e);
step6 = imerode(step5,SE_e);
figure;
subplot(2,2,1);imshow(step2);title('Binarized Second layer of HSV');
subplot(2,2,2);imshow(step4);title('Output of Opening with SE\_d');
subplot(2,2,3);imshow(step5);title('After 1st erosion with SE\_e');
subplot(2,2,4);imshow(step6);title('After 2st erosion with SE\_e');
%% Task 2
% (a) Binarization
%%
% load image
plate = imread('../Lab5 material/car_license_plate.png'); 
% (a) binarization
bin_plate = plate>19;
figure;imshow(bin_plate);
%% 
% (b) Character detection
%%
% load template
ch_template = imread('../Lab5 material/alphanumeric_templates.png');
bin_template = logical(ch_template) .* (ch_template~=19);
figure;imshow(bin_template);
% letters
letters = bin_template(37:314,27:1072);
figure;imshow(letters);
% numbers 
numbers = bin_template(335:515,37:485);
figure;imshow(numbers);
%% 
% letters cropping
%%
% placeholder
letter = zeros(92,104,26);
figure;
for position = 1:26
    end1 = ceil(position/10) * 92;
    end2 = (position - 10 * (ceil(position/10) - 1)) * 104;
    letter(:,:,position) = letters((end1-91):end1,(end2-103):end2);
    % show separated letters
    subplot(6,5,position);imshow(letter(:,:,position));
end
%% 
% numbers cropping
%%
% placeholder
number = zeros(90,89,10);
figure;
for value = 0:9
    position = value + 1;
    end1 = ceil(position/5) * 90;
    end2 = (position - 5 * (ceil(position/5) - 1)) * 89;
    number(:,:,position) = numbers((end1-89):end1,(end2-88):end2);
    % show separated numbers
    subplot(2,5,position);imshow(number(:,:,position));
end
%% 
% Character and Number Detection in Task 2 (b)
%%
letter_set = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
SE_thinner = strel('disk',3);
SE_thinner_1 = strel('disk',1);
thin_letter = imerode(letter,SE_thinner);
thin_letter = imerode(thin_letter,SE_thinner_1);
figure;
for position = 1:26
    % show separated letters
    subplot(6,5,position);imshow(thin_letter(:,:,position));
end
thin_number = imerode(number,SE_thinner);
figure;
for position = 1:10
    % show separated letters
    subplot(2,5,position);imshow(thin_number(:,:,position));
end
% test detection
figure;
for position = 1:26
test_detection = imopen(bin_plate,thin_letter(:,:,position));
subplot(9,3,position);imshow(test_detection);title(letter_set(position));
end
% number detection
figure;
for position = 1:10
test_detection = imopen(bin_plate,thin_number(:,:,position));
subplot(5,2,position);imshow(test_detection);title(num2str(position-1));
end
%% 
% (c) Implement a function that is able to detect content of a plate.
%%
% Create input image for detection
% top-left corner: (155,34)-bottom right corner: (619,114)
% input image for plate content detection
input_plate = bin_plate(19:132,132:649);
figure;imshow(input_plate);
output_v1 = my_detect_car_license_plate_v1(input_plate,thin_letter,thin_number);
disp(['V1: The plate says: ' output_v1]);
%% 
% Generation of background for hit-miss operation. foreground is thin_letter
%%
SE_fat = strel('disk',8);
SE_thin = strel('disk',5);
contour_letter = imdilate(letter,SE_fat) - imdilate(letter,SE_thin);
contour_number = imdilate(number,SE_fat) - imdilate(number,SE_thin);
figure;
for position = 1:26
    % show separated letters
    subplot(6,5,position);imshow(contour_letter(:,:,position));
end
figure;
for position = 1:10
    % show separated letters
    subplot(2,5,position);imshow(contour_number(:,:,position));
end
% letter detection
figure;
for position = 1:26
hm_detection = bwhitmiss(bin_plate,thin_letter(:,:,position),contour_letter(:,:,position));
hm_detection = bwareafilt(hm_detection,[1 50]);
subplot(9,3,position);imshow(hm_detection);title(letter_set(position));
end
% number detection
figure;
for position = 1:10
hm_number_detection = bwhitmiss(bin_plate,thin_number(:,:,position),contour_number(:,:,position));
subplot(5,2,position);imshow(hm_number_detection);title(num2str(position-1));
end

%% 
% (d) Implement the function my_detect_car_license_plate_v2 using hit-miss 
% filter
%%
output_v2 = my_detect_car_license_plate_v2(bin_plate,thin_letter,contour_letter,thin_number,contour_number);
disp(['V2: The plate says: ' output_v2]);