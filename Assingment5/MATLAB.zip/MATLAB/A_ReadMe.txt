Welcome to the dir of code.

Lab5_Morphology.mlx is the LiveScript file to demonstrate 
the whole assignment of Lab 5.
Please view the result of Task 1 at the section named Step 7 with one line output: The number of coins in image im_coins is 17.
And the result of Task 2 can be seen in the Live Script starting from the section named Task 2.

my_detect_car_license_plate_v1.m
my_detect_car_license_plate_v2.m
Lab5_Morphology.m 
are files required by the tasks.
The other three .m files are solely for debugging during developing the above four mentioned files.