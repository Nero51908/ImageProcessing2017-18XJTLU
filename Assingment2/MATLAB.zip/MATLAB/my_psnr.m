function output = my_psnr(input,reference)
% check whether the input matrix is of the same size as reference matrix
if size(input) ~= size(reference)
    %if not, print error message and return to command line
    disp('input error: inconsistant image size');
    return
end
%recognize input type:how many gray levels
n = class(input);
switch n
    case 'uint8'
        R = 2^8;
    case 'uint16'
        R = 2^16;
    case 'uint32'
        R = 2^32;
    otherwise
        R = 1;
%end of conditions
end
%convert uint type to double type for noninteger values
%without such type conversion, the formula of PSNR won't work because
%values are limited to be integer by the type of uint8/16/32 during the
%calculation of PSNR.
input = double(input);
reference = double(reference);
%calculate MSE which is not necessarily an integer.
MSE = sum(sum((input-reference) .^ 2)) / (size(input,1) * size(input,2));
%calculate PSNR using definition.
output = 10 * log10((R-1)^2 / MSE);
%end of function
end
