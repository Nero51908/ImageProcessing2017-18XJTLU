function [psnr, outputimage,x1,x2,x3,y1,y2,y3] = my_pieceWiseMapping_anchorout( input, reference, outputlevels, sideSlope, windowStart, windowLength)
% input: input image for piecewise linear graylevel mapping

% reference: the reference image for PSNR calculation

% outputlevels: deisgnate number of possible graylevels in the output image

% shape of the piecewise line is determined by following three arguments:
% from left to right they are refered to as
%                stage 1;  middle;   stage 3
% sildeSlope:  
    % my piecewise line has three parts
    % the two on the sides are compressing graylevel distribution
    % the one in the middle is stretching graylevel distritution
    % as a result, the output image should have a larger dynamic range than the
    % input.
    % side slope is the slope of the two compressing segments
% windowStart specifies the starting gray level of the stretching segment

% windowLength specifies the horizontal projection of the stretching segment(in the middle)

%% input argument check
if outputlevels ~= floor(outputlevels)
    disp('Number of gray levels of the output image must be an integer');
    return
end

%% determine how many possible gary levels are there in the input image
% formulas may refer this number as L
% this part can be changed as a explicit input from user
switch class(input)
    case 'uint8'
        inputlevels = 2^8;
    case 'uint16'
        inputlevels = 2^16;
    case 'uint32'
        inputlevels = 2^32;
    otherwise
        inputlevels = 256;
%end of conditions
end
%change input type to double;
input = double(input);
%% Obtain analytic description of piecewise line 
% i.e., functions from x to y (mapping rules), where x is input graylevel and y is output graylevel
% equation of lines: y = kx + b, k implies slope and b implies vertical
% intersection in code below
% contruct a coordinate and piecewise line for mapping
% three anchor points are represented by x1, x2, x3; y1, y2, y3.
% original point is 0
% x3 and y3 are given by the highest possible gray level indices of input
% and output images
% x1 and x2 are determined by input arguments windowStart and windowLength
x1 = windowStart - 1;
x2 = x1 + windowLength - 1;
% note that gray index starts from 0, the highest possible index in the input should
% be inputlevels - 1.
%
y1 = x1 * sideSlope;
%
x3 = inputlevels - 1; % for instance that the input image is uint8 
y3 = outputlevels - 1;
%with a known point and slope, y2 can be calculated from x2
b_stage3 = y3 - sideSlope * x3;
y2 = x2 * sideSlope + b_stage3;
%slope of the segment in the middle (the line for stretching)
k_middle = (y2 - y1) / (x2 - x1);
b_middle = (y1*x2 - y2*x1)/(x2 - x1);
% allocate positions to be compressed in the input matrix
stage1elem = input(input < x1);
stage3elem = input(input > x2);
% allocate positions to be stretched in the input matrix
stage2elem = input(input >= x1 & input <= x2);
disp('middle slope is');
disp(k_middle);
disp('b_middle');disp(b_middle);
% stage 1 mapping
input(input < x1) = stage1elem * sideSlope;
% stage 3 mapping
input(input > x2) = stage3elem * sideSlope + b_stage3;
% stage 2 mapping
input(input >= x1 & input <= x2) = stage2elem * k_middle + b_middle;
%% output
% assign output image
switch class(input)
    case 'uint8'
        outputimage = uint8(input);
    case 'uint16'
        outputimage = uint16(input);
    case 'uint32'
        outputimage = uint32(input);
    otherwise
        outputimage = uint8(input);
%end of conditions
end

% assign psnr for output and show psnr
disp('PSNR with respect to your reference image:');
psnr = my_psnr(outputimage, reference);
disp(psnr);
disp('Anchor point x coordinates:');disp([0,x1,x2,x3]);
disp('Achor point y coordinates:');disp([0,y1,y2,y3]);
end
