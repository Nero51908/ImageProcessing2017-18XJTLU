%% my implementation of meidan filtering
function output = my_medianFilter(input,mask_size)
%% input check mask_size should be odd
if ~all(mod(mask_size,2))
    disp('Error: mask_size must be a 1 by 2 matrix of odd integers');
    return;
end
% input mask_size as an arry [p , q] representing a p by q mask
% Four pixels at the corners will be kept intacked 
% edges are evaluated by padding themselves
% creating placeholder for median operation. each column corresponds to one pixel
%% zero padding
pad_input = padarray(input,(mask_size - 1)/2,'replicate');
%%
 neighbourhood = zeros(prod(mask_size),numel(input));%warning: implicit
% type convertion 'double' here.
%% applying mask
%find all neighbour pixels
for linear_position = 1:prod(mask_size)
    p_position = mod(linear_position, mask_size(1));
    q_position = ceil(linear_position / mask_size(1));
    if p_position == 0
        p_position = mask_size(1);
    end
    %move window and create vector to assign all layers of neighbourhood
    %matrix.
    buffer_matrix = pad_input( (1:size(input,1)) + p_position - 1 , (1:size(input,2)) + q_position - 1 ); %(mask_size(1)-1)/2 + p_position - center_position(1) = p_position - 1
    neighbourhood(linear_position,:) = buffer_matrix(:);
end
neighbourhood = sort(neighbourhood);
output = uint8(vec2mat(neighbourhood( (prod(mask_size) + 1) / 2 , : ),size(input,1))');
end
