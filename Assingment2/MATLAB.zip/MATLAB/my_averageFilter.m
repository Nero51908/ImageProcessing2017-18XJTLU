%% my implementation of Average filter based on my implementation of median filter
function output = my_averageFilter(input,mask_size)
%% input check mask_size should be odd
if ~all(mod(mask_size,2))
    disp('Error: mask_size must be a 1 by 2 matrix of odd integers');
    return;
end
% input mask_size as an arry [p , q] representing a p by q mask
% Four pixels at the corners will be kept intacked 
% edges are evaluated by padding themselves
% creating placeholder for median operation. each column corresponds to one pixel
%% zero padding
pad_input = padarray(input,(mask_size - 1)/2,'replicate');
%%
 neighbourhood = zeros(prod(mask_size),numel(input));
%%%%%%%%%%%%%%warning: implicit type convertion 'double' here.
%% applying mask
%center_position = (mask_size + 1) / 2;% center of the mask
for linear_position = 1:prod(mask_size)
    p_position = mod(linear_position, mask_size(1));
    q_position = ceil(linear_position / mask_size(1));
    if p_position == 0
        p_position = mask_size(1);
    end
% disp('p q'); disp([p_position,q_position]);
    buffer_matrix = pad_input( (1:size(input,1)) + p_position - 1 , (1:size(input,2)) + q_position - 1 ); %(mask_size(1)-1)/2 + p_position - center_position(1) = p_position - 1
    neighbourhood(linear_position,:) = buffer_matrix(:);
end
output = uint8(vec2mat(mean(neighbourhood),size(input,1))');
end
