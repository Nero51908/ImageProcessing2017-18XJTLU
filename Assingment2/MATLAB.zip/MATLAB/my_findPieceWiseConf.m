%% select one piece-wise config from a set of linear mapping configs
function output = my_findPieceWiseConf(input, im_ref, gray_levels)
% generate histogram of the input image
input_histogram = imhist(input);
% start trying !!no retry in this version
%% this is the kernel of selecting loop
%criteria setting
%avgAppearance = mean(input_histogram);
rectifier = find(input_histogram >= 300);
% window size in terms of pixels 
windowSizeEstm = rectifier(end) - rectifier(1) + 1;
% start point of the window in terms of matrix index
windowStartEstm = rectifier(1);
%
x3 = gray_levels - 1; % for instance that the input image is uint8 
y3 = x3;
%
guess_k = 0.6; % positive num smaller than 1
%
b_stage3 = y3 - guess_k * x3;
y1 = guess_k * x1;
y2 = x2 * guess_k + b_stage3;
disp('anchors');disp(x1);disp(x2);disp(y1);disp(y2);
stage1elem = input(input < x1);
stage3elem = input(input > x2);
stage2elem = input(input >= x1 & input <= x2);
k_middle = (y2 - y1) / (x2 - x1);
disp('middle slope is');
disp(k_middle);
b_middle = (y1*x2 - y2*x1)/(x2 - x1);
disp('b_middle');disp(b_middle);
% stage 1 mapping
input(input < x1) = stage1elem * guess_k;
% stage 3 mapping
input(input > x2) = stage3elem * guess_k + b_stage3;
% stage 2 mapping
input(input >= x1 & input <= x2) = stage2elem * k_middle + b_middle;
% output
output = input;
% kernel psnr
disp('psnr'); disp(my_psnr(output, im_ref));
disp('anchors');disp(x1);disp(x2);disp(x3);disp(y1);disp(y2);disp(y3);
x = linspace(1,x3,x3);
y_1 = x * guess_k;
y_2 = x * k_middle + b_middle;
y_3 = x * guess_k + b_stage3;
plot(x,y_1,x,y_2,x,y_3);
end
