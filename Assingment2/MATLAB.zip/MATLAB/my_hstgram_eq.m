%% implementation of histogram equalization
function output = my_hstgram_eq(input,outputLevels)
%% determine how many possible gary levels are there in the input image
% formulas may refer this number as L
% this part can be changed as a explicit input from user
inputType = class(input); 
switch inputType
    case 'uint8'
        inputlevels = 2^8;
    case 'uint16'
        inputlevels = 2^16;
    case 'uint32'
        inputlevels = 2^32;
    otherwise
        inputlevels = 256;
%end of conditions
end
%% mapping
% obtain a histogram of the input
input_histo = imhist(input);
%convert input to double 
input = double(input);
% normalize the histogram
% normalized_histo = input_histo/sum(input_histo);
number_of_pixels = numel(input);% N
% outputLevels is L
L_over_N = outputLevels / number_of_pixels;
% x axis is intput 
% y axis is output
x = 0 : (inputlevels - 1);
y = 0 : (outputLevels - 1);
for i = x
    input(input == i) =  L_over_N * sum(input_histo(1:(i + 1)));
end
% output formatting
switch inputType
    case 'uint8'
        output = uint8(input);
    case 'uint16'
        output = uint16(input);
    case 'uint32'
        output = uint32(input);
    otherwise
        output = uint8(input);
        %end of conditionsdisp(output);

end