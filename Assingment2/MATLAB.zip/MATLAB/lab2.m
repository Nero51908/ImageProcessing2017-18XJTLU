%% Lab 2
%% Task 2 (30')
% load image
im = imread('./lab2_imagedemo/lenna512.bmp');
% add zero mean Gaussian noise to im with variance 10
im_wn = imnoise(im,'gaussian', 0, 10);
% add salt&pepper noise to im, density 10%
im_sp = imnoise(im,'salt & pepper',0.1);
% load low dynamic range image
im_low_dynamic_range = imread('./lab2_imagedemo/lenna512_low_dynamic_range.bmp');
%psnr with reference to im
psnr_im_wn = my_psnr(im_wn, im);
psnr_im_sp = my_psnr(im_sp, im);
psnr_im_low_dynamic_ran = my_psnr(im_low_dynamic_range, im);
%show images
figure('Name','Comparing 4 Images and Histograms');
subplot(4,2,1);
imshow(im);
title('Reference Image');
subplot(4,2,3);
imshow(im_wn);
title(['White Noies Added (PSNR: ' num2str(psnr_im_wn) ')']);
subplot(4,2,5);
imshow(im_sp);
title(['Salt & Pepper (PSNR: ' num2str(psnr_im_sp) ')']);

subplot(4,2,7);
imshow(im_low_dynamic_range);
title(['Low Dynamic Range (PSNR: ' num2str(psnr_im_low_dynamic_ran) ')']);

%histogram
subplot(4,2,2);
imhist(im);
title('Reference Image');
subplot(4,2,4);
imhist(im_wn);
title('White Noise Added');
subplot(4,2,6);
imhist(im_sp);
title('Salt & Pepper');
subplot(4,2,8);
imhist(im_low_dynamic_range);
title('Low Dynamic Range');
%% Task 3 (20')
[out_im_psnr,outputIm] = my_pieceWiseMapping( im_low_dynamic_range, im , 256 , 0.196 , 50 , 157);
figure('Name','Output of a run of piecewise linear mapping')
imshow(outputIm);title(['The best PSNR found:' num2str(out_im_psnr)]);disp(['The best PSNR:' num2str(out_im_psnr)]);
%% Task 4 (20')
equalized_im_low = my_hstgram_eq(im_low_dynamic_range,256);
matlab_eq_im_low = histeq(im_low_dynamic_range);
figure('Name','Comparing my_hstgram_eq() and histeq()');
subplot(2,2,1);
imshow(equalized_im_low);
title('Output of my\_hstgram\_eq()');
subplot(2,2,2);
imhist(equalized_im_low);
title('Output of my\_hstgram\_eq()');
subplot(2,2,3);
imshow(matlab_eq_im_low);
title('Output of histeq()');
subplot(2,2,4);
imhist(matlab_eq_im_low);
title('Output of histeq()');
% compare with task 3
equalized_im_low = my_hstgram_eq(im_low_dynamic_range,256);
matlab_eq_im_low = histeq(im_low_dynamic_range);
figure('Name','Comparing task4 with task3');
subplot(2,2,1);
imshow(equalized_im_low);
title('task4 output');
subplot(2,2,2);
imhist(equalized_im_low);
title('task4 output');
subplot(2,2,3);
imshow(outputIm);
title('task3 output');
subplot(2,2,4);
imhist(outputIm);
title('task3 output');
%% Task 5 (20')
%median filter
%3 by 3
im_sp_medfilter_3_by_3 = my_medianFilter(im_sp,[3,3]);
%5 by 5
im_sp_medfilter_5_by_5 = my_medianFilter(im_sp,[5,5]);
%averaging filter 
%3 by 3
im_sp_avgfilter_3_by_3 = my_averageFilter(im_sp,[3,3]);
%5 by 5
im_sp_avgfilter_5_by_5 = my_averageFilter(im_sp,[5,5]);
%show
figure('Name','Comparing Performance of Median and Averaging Filters');
subplot(3,2,1);
%im
imshow(im);
title('Reference image: im');

subplot(3,2,2);
%im_sp
imshow(im_sp);
title(['Input image: im\_sp PSNR: ' num2str(my_psnr(im_sp,im))]);

subplot(3,2,3);
imshow(im_sp_medfilter_3_by_3);
title(['3 by 3 Median Filter PSNR: ' num2str(my_psnr(im_sp_medfilter_3_by_3,im))]);

subplot(3,2,4);
imshow(im_sp_medfilter_5_by_5);
title(['5 by 5 Median Filter PSNR: ' num2str(my_psnr(im_sp_medfilter_5_by_5,im))]);

subplot(3,2,5);
imshow(im_sp_avgfilter_3_by_3);
title(['3 by 3 Averaging Filter PSNR: ' num2str(my_psnr(im_sp_avgfilter_3_by_3,im))]);

subplot(3,2,6);
imshow(im_sp_avgfilter_5_by_5);
title(['5 by 5 Averaging Filter PSNR: ' num2str(my_psnr(im_sp_avgfilter_5_by_5,im))]);
truesize;
% figure('Name','im_sp filtered by 3 by 3 medianfilter'); imshow(im_sp_medfilter_3_by_3);
% 
% figure('Name','im_sp filtered by 5 by 5 medianfilter'); imshow(im_sp_medfilter_5_by_5);
%comparing filtered two and the original im_sp
% subplot(1,3,2);
% imshow(im_sp);
% title('original im\_sp');
% subplot(1,3,3);
% imshow(im_sp_medfilter_5_by_5);
% title('filtered by 5 by 5 mask');
% %apply 3 by 3 average filter
% figure('Name','Apply 3 by 3 average filter to im_sp');
% subplot(1,2,1);
% imshow();
% title('Average filtered im\_sp');
% subplot(1,2,2);
% imshow(im_sp);
% title('original im\_sp');

