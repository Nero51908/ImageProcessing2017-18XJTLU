%% GUI: select the best looking piecewise mapping
% GUI initialization code based on MATLAB demo in documentation
function mypiecewiseGUI
    f = figure('Visible','off');

    % Create slider
    sld = uicontrol('Style', 'slider',...
        'Min',0,'Max',1,'Value',0.5,...
        'Position', [400 20 120 20],...
        'Callback', @mypieceWiseMapping);

    % Add a text uicontrol to label the slider.
    txt = uicontrol('Style','text',...
        'Position',[400 45 120 20],...
        'String','side slope');
    f.Visible = 'on';
end

%% my_piecewiseMapping for piecewiseGUI
% truncated version of my_pircewiseMapping.m for GUI callback
function mypieceWiseMapping(source,event)
input = imread('./lab2_imagedemo/lenna512_low_dynamic_range.bmp');   
windowStart = 60;
windowLength = 140;
% my piecewise line has three parts
% the two on the sides are compressing graylevel distribution
% the one in the middle is stretching graylevel distritution
% as a result, the output image should have a larger dynamic range than the
% input.
% side slope is the slope of the two compressing segments
    % windowStart specifies the starting gray level of the stretching segment
    % windowLength specifies the horizontal projection of the stretching
    % segment
    % shape of the piecewise line is determined by the three
    % specifications.
    %
    % bisides the original point
    % three other anchor points are represented as x1, x2, x3; y1, y2, y3.
    %
    %output levels specifies verticle axis index of the linear mapping
    %
    % original point is 0
    % x3 and y3 are given by the highest gray index
    switch class(input)
        case 'uint8'
            inputlevels = 2^8;
        case 'uint16'
            inputlevels = 2^16;
        case 'uint32'
            inputlevels = 2^32;
        otherwise
            inputlevels = 256;
            %end of conditions
    end
    % x1 and x2 are determined by input arguments
    x1 = windowStart - 1;
    x2 = x1 + windowLength - 1;
    % note that gray index starts from 0, the highest possible index in the input should
    % be inputlevels - 1.
    %
    y1 = x1 * source.Value;
    %
    x3 = inputlevels - 1; % for instance that the input image is uint8
    y3 = inputlevels - 1;
    %with a known point and slope, y2 can be calculated from x2
    b_stage3 = y3 - source.Value * x3;
    y2 = x2 * source.Value + b_stage3;
    %slope of the segment in the middle (the line for stretching)
    k_middle = (y2 - y1) / (x2 - x1);
    b_middle = (y1*x2 - y2*x1)/(x2 - x1);
    % show the middle two anchor points
    % disp('anchors');disp(x1);disp(x2);disp(y1);disp(y2);
    % allocate positions to be compressed
    stage1elem = input(input < x1);
    stage3elem = input(input > x2);
    % allocate positions to be stretched
    stage2elem = input(input >= x1 & input <= x2);
    disp('middle slope is'); disp(k_middle);
    disp('b_middle'); disp(b_middle);
    disp('sideSlope'); disp(source.Value)
    % stage 1 mapping
    input(input < x1) = stage1elem * source.Value;
    % stage 3 mapping
    input(input > x2) = stage3elem * source.Value + b_stage3;
    % stage 2 mapping
    input(input >= x1 & input <= x2) = stage2elem * k_middle + b_middle;
imshow(input);
end