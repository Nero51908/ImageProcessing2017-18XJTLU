%% test ref
% my_median test
tic;testmedian_2 = my_medianFilter(testmedian,[3,3]);toc;figure;imshow(testmedian_2);