%% EEE330 Lab 1
%% Taks 1: Load and Display Lenna.bmp

% read lenna512.bmp
figure('Name','Original Lenna');
lenna = imread('lenna512.bmp');
image(lenna);
colormap(gray(256)); truesize;
% use different colormap specifications
figure('Name','Try different color maps')
%
subplot(2,2,1)
imshow(lenna,gray(64))
title('gray 64')
%
subplot(2,2,2)
imshow(lenna,cool(256))
title('cool 256')
%
subplot(2,2,3)
imshow(lenna,hot(256))
title('hot 256')
%
subplot(2,2,4)
imshow(lenna,gray(128))
title('gray 128')
% set all images as truesize (may cause "exceeding range")
truesize
%% Task 2 (1) Show a cropped picture showing lenna's face
% Convetion of positioning: positive y direction is horizongtally pointing to 
% right; positive x direction is vertically pointing downward.
% 
% The cordinate system described by x and y directions comply to matrix indexing 
% notation in linear algebra and MATLAB matrix indexing convention.
%%
% crop lenna using imcrop function
face_lenna = imcrop(lenna,gray(256),[190,158,380-165,380-165]); %380 - 165 = 215
% crop lenna by indexing the image matrix
face_lenna_my = lenna(158:158+215,190:190+215);
% show the two cropped images and the original lenna
figure('Name','Compare function imcrop and simple matrix indexing');
subplot(1,3,1);
image(lenna);
title('Original Lenna');
%
subplot(1,3,2);
image(face_lenna);
title('Result of function imcrop');
%
subplot(1,3,3);
image(face_lenna_my);
title('Cropping by matrix indexing');
%
colormap(gray(256));
%% Task 2 (2) (a) Nearest Neighbour Interpolation Downsampling
%%
%Output of Downsampling is actually scalling.
scale_2_2_a = 1/2;
%use 
downsampled_lenna = my_nearestNeighScaling(lenna,scale_2_2_a);
figure('Name','Comparing Lenna with its downsampled vesion');
subplot(1,2,1);
image(lenna);
title('Original Image')
subplot(1,2,2);
image(downsampled_lenna);
title('Downsampled Image')
colormap(gray(256));
%% Task 2 (2) (b) Upsample the downsampled lenna
%%
scale_2_2_b = 2;
upsampled_d_lenna = my_nearestNeighScaling(downsampled_lenna,scale_2_2_b);
figure('Name','Comparing Lenna with its upsampled vesion of the downsampled one');
subplot(1,2,1);
image(downsampled_lenna);
title('Downsampled Lenna')
subplot(1,2,2);
image(upsampled_d_lenna);
title('Upsampled version')
colormap(gray(256));
%% Task 2 (2) (c) Repeat the operation in a and b with Bilinear interpolation
%%
% bilinear downsampling
bi_downsampled_lenna = my_bilinear_v2(lenna,scale_2_2_a);
figure('Name','Comparing Lenna with its bilinear downsampled vesion');
subplot(1,2,1);
image(lenna);
title('Original Image')
subplot(1,2,2);
image(bi_downsampled_lenna);
title('Bilinear Downsampled Image')
colormap(gray(256));
% bilinear upsampling
bi_upsampled_d_lenna = my_bilinear_v2(bi_downsampled_lenna,scale_2_2_b);
figure('Name','Comparing Lenna with its upsampled vesion of the downsampled one');
subplot(1,2,1);
image(bi_downsampled_lenna);
title('Bilinear Downsampled Lenna')
subplot(1,2,2);
image(bi_upsampled_d_lenna);
title('Bilinear Upsampled version')
colormap(gray(256));
%% Task 2 (2) (d) Calculate PSNR of the two upsampled images with reference to original lenna
%%
my_psnr_nearest = my_psnr(upsampled_d_lenna,lenna)
my_psnr_bilinear = my_psnr(bi_upsampled_d_lenna,lenna)
psnr_nearest = psnr(upsampled_d_lenna,lenna)
psnr_bilinear = psnr(bi_upsampled_d_lenna,lenna)
%% Task2 (3) Reduce gray levels of lenna from 256 to 16
%%
gray_16_lenna = lenna / 16;
figure('Name','Comparing 256 gray level and 16 gray level');
subplot(1,2,1);
imshow(lenna,gray(256));
title('Original Lenna')
subplot(1,2,2);
imshow(gray_16_lenna,gray(16));
title('16 gray-level version')