function output = my_bilinear_v2(input,scale)
inputType = class(input);
intput = double(input);
inputSize = size(input);
targetSize = floor(inputSize * scale);
%map targetPositions into input image
role_mappingPositions = linspace(1,inputSize(1),targetSize(1));%1:mappingDist(1):inputSize(1); % role
column_mappingPositions = linspace(1,inputSize(2),targetSize(2));%1:mappingDist(2):inputSize(2); % column
%
x1 = floor(role_mappingPositions); % x1
y1= floor(column_mappingPositions); %y1
x2 = ceil(role_mappingPositions);
y2 = ceil(column_mappingPositions);
%
role_intPositions = role_mappingPositions == x1;
column_intPositions = column_mappingPositions == y1;
%
role_weight = role_mappingPositions - x1;
column_weight = column_mappingPositions - y1;
roleweight_conju = 1 - role_weight;
columnweight_conju = 1 - column_weight;
%
weightedZ11 = intput(x1,y1) .* columnweight_conju .* roleweight_conju;
weightedZ12 = intput(x1,y2) .* column_weight .* roleweight_conju;
weightedZ21 = intput(x2,y1) .* columnweight_conju .* role_weight;
weightedZ22 = intput(x2,y2) .* column_weight .* role_weight;
output = weightedZ11 + weightedZ12 + weightedZ21 + weightedZ22;
switch inputType
    case 'uint8'
        output = uint8(output);
    case 'uint16'
        output = uint16(output);
    otherwise
        output = uint32(output);
        %end of conditions
end
disp(inputType);
end
