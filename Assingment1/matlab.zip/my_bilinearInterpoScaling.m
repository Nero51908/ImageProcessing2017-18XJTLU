function output = my_bilinearInterpoScaling( inputImage, scale)
%stop watch start 
tic
% convert all gray levels to type double for calculation
inputImage = double(inputImage);
originalImageSize = size(inputImage);
targetedImageSize = floor(originalImageSize * scale);
% initialize output matrix for speed
output = zeros(targetedImageSize);

%% integer special case
% special case detection: scaling result is integer sized, no need to floor
% or ceil the coordinate.
if (targetedImageSize(1) - 1) / scale == round((targetedImageSize(1) - 1) / scale) && (targetedImageSize(2) - 1) / scale == round((targetedImageSize(2) - 1) / scale)
    % if all cordinates are integer, use the specialized formula for
    % integers.
    
    % mapping the targeted image positions back to the original image
    x_mapping = (0:(targetedImageSize(1) - 1)) / scale + 1;
    y_mapping = (0:(targetedImageSize(2) - 1)) / scale + 1;
    % calculate values for targeted image
    for x = 1:targetedImageSize(1)
        for y = 1:targetedImageSize(2)
            output(x,y) = [1 0] * [inputImage(x_mapping(x),y_mapping(y)) inputImage(x_mapping(x),y_mapping(y)); inputImage(x_mapping(x),y_mapping(y)) inputImage(x_mapping(x),y_mapping(y))] * [0 ; 1];  
        end
    end
    % convert all values to usigned integer (gray level quantization)
    output = uint8(output);
    % read top watch
    toc
    % return to command window
    return
end

%% general case
% positions_x = 0:(targetedImageSize(1) - 1); %output image pixel indexing. index 1 is rows; index 2 is columns.
% positions_y = 0:(targetedImageSize(2) - 1);

%non-integer coordinates representing the output image within the original
%image
x_mapping = ((1:targetedImageSize(1)) - 1) / ((targetedImageSize(1) - 1) / (originalImageSize(1) - 1)) + 1;%row 1 is x; row 2 is y. x is row in output picture, y is column in output picture.
y_mapping = ((1:targetedImageSize(2)) - 1) / ((targetedImageSize(2) - 1) / (originalImageSize(2) - 1)) + 1;

%allocate neighbours of each mapped point for output
x_1 = floor(x_mapping);
y_1 = floor(y_mapping);
x_2 = ceil(x_mapping);
y_2 = ceil(y_mapping);
%
role_weight = x_mapping - x_1;
column_weight = y_mapping - y_1;
roleweight_conju = 1 - role_weight;
columnweight_conju = 1 - column_weight;

%assign output image matrix
% for x = 2:targetedImageSize(1)-1
%     for y = 2:targetedImageSize(2)-1
%         output(x,y) = [(y_2(y) - y_mapping(y)) (y_mapping(y) - y_1(y))] * [inputImage(x_1(x),y_1(y)) inputImage(x_2(x),y_1(y)); inputImage(x_1(x),y_2(y)) inputImage(x_2(x),y_2(y))] * [x_2(x)-x_mapping(x); x_mapping(x)-x_1(x)];
%     end
% end
weightedZ11 = inputImage(x_1,y_1) .* columnweight_conju .* roleweight_conju;
weightedZ12 = inputImage(x_1,y_2) .* column_weight .* roleweight_conju;
weightedZ21 = inputImage(x_2,y_1) .* columnweight_conju .* role_weight;
weightedZ22 = inputImage(x_2,y_2) .* column_weight .* role_weight;
output = weightedZ11 + weightedZ12 + weightedZ21 + weightedZ22;
%output time
output = uint8(output);

% read stop watch
toc
end