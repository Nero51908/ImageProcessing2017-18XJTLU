function output = my_nearestNeighScaling ( inputimage, scale)
inputSize = size(inputimage);
targetSize = floor(inputSize * scale);
mappingDist = (inputSize - 1) ./ ( targetSize - 1 );
%map targetPositions into input image
role_mappingPositions = round(1:mappingDist(1):inputSize(1)); % role
column_mappingPositions = round(1:mappingDist(2):inputSize(2)); % column
%Define size of the output picture by one dimensional positions
output = inputimage(role_mappingPositions,column_mappingPositions);